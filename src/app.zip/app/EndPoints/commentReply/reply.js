import { apiSlice } from "../faseBaseQuery";

export const projectEndPoint = apiSlice.injectEndpoints({
  endpoints: (builder) => ({ 

    createReply: builder.mutation({
      query: (data) => {
        return {
          url: `/ideamall/premise-Reply`,
          method: "POST",
          body: data,
        };
      },
    }),
    getAllReplyOfAComment : builder.query({
        query: (id) => ({
          url: `/ideamall/premise-Reply/${id}`,
          method: "GET",
        }),
      }),

    updateLikeOfReply : builder.mutation({
        query: (id) => ({
          url: `/ideamall/premise-Reply/${id}`,
          method: "PATCH",
        }),
      }),
    deleteLikeOfReply : builder.mutation({
        query: (id) => ({
          url: `/ideamall/premise-Reply/${id}`,
          method: "DELETE",
        }),
      }),
   
  }),
});

export const {
useCreateReplyMutation,
useGetAllReplyOfACommentQuery,
useUpdateLikeOfReplyMutation,
useDeleteLikeOfReplyMutation

} = projectEndPoint;