import { useState } from "react";
import { toast } from "react-toastify";
import { useRequestForSaleOrTranslateMutation } from "../../../app/EndPoints/premisePoolApi";
import crossIcon from "../../../img/Icons/crossIcon.png";
import TypingLoader from "../../TypingLoader";
import SameNamePop from "./alerts/SameNamePop";
import SuccessPop from "./SuccessPop";

const ReqSalePop = ({ popClose, id, user, source_language, project_id }) => {
  const [reqSale] = useRequestForSaleOrTranslateMutation();
  const [successPop, setSuccessPop] = useState(false);
  const [errorPop, setErrorPop] = useState(false);
  const [processing, setProcessing] = useState(false);

  const handleSaleRequestSubmit = async () => {
    setProcessing(true);
    try {
      const data = {
        premise_id: id,
        request_type: "Sale",

        user_id: user,
      };

      const response = await reqSale(data);

      if (response) {
        toast.success("Sale request submitted successfully!");
        setSuccessPop(true); // Open success popup first
        setProcessing(false);
        // setTimeout(() => popClose(null), 500);
      } else {
        //toast.error("Failed to submit the sale request. Please try again.");
        setErrorPop(true);
        setProcessing(false);
      }
    } catch (error) {
      //toast.error("An error occurred while submitting the request.");
      console.error("Error:", error);
      setProcessing(false);
      setErrorPop(true);
    }
  };

  if (successPop) {
    return (
      <SuccessPop
        requestType={"sale"}
        popClose={setSuccessPop}
        parentClose={popClose}
      />
    );
  }
  if (errorPop) {
    return (
      <SameNamePop
        popClose={setErrorPop}
        title="Failed to submit the sale request. Please try again"
      />
    );
  }

  return (
    <div className="fixed top-0 bottom-0 right-0 left-0 w-full h-screen flex items-end sm:items-center bg-[#252525b0] justify-center z-[21] ">
      {/* <ToastContainer /> */}
      {processing ? (
        <div className="w-full md:w-[400px]">
          <TypingLoader />
        </div>
      ) : (
        <div className=" h-[60vh] sm:h-[350px] px-[22px] w-full bg-[#fff] max-w-[436px]  md:mx-auto relative  rounded-[8px]">
          {/* close popup */}
          <div className="absolute top-[-76px] sm:top-[-12px] right-[45%] ml-4 sm:ml-0 sm:right-[-15px]">
            <img
              src={crossIcon}
              alt=""
              className=" text-red-500  w-8 h-8 cursor-pointer"
              onClick={() => popClose(null)}
            />
          </div>
          <h2 className="font-[600] text-[16px] leading-[19.9px] text-center mt-[18px]">
            Make the Premise Project your own!
          </h2>
          <div className="h-[1px] mt-[8px] w-full mx-auto bg-[#a1a1a1]" />
          <div>
            <p className="text-center text-[14px] leading-[14.5px] font-[500] my-[12px] text-[#616161] w-[80%] mx-auto">
              You may request the owner of this Premise Project to transfer its
              ownership to you.
            </p>

            <h2 className="font-[400] text-[14px] leading-[14.5px] text-[#616161] text-left mt-[16px]">
              If Premise Project owner accepts your request :
            </h2>
            <div className="mt-[10px] pl-[8px]  flex gap-[4px]">
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                1.{" "}
              </p>
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                After transfer the Premise Project will be visible in Premise
                Pool as your own Premise instead of the current owner.
              </p>
            </div>
            <div className="mt-[6px] pl-[8px]  flex gap-[4px]">
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                2.{" "}
              </p>
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                You will be able to brainstorm further on the Premise and add
                comment etc to the Beat Sheet.
              </p>
            </div>
            <div className="mt-[6px] pl-[8px]  flex gap-[4px]">
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                3.{" "}
              </p>
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                You will be able to make the Premise private.
              </p>
            </div>
            <div className="mt-[6px] pl-[8px]  flex gap-[4px]">
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                4.{" "}
              </p>
              <p className="text-left text-[14px] leading-[14.5px] font-[400]  text-[#616161] ">
                You will be able to monetize this Premise Project through
                purchase or Translation.
              </p>
            </div>
          </div>

          <div className="w-[134px] mx-auto mt-[12px]">
            <button
              onClick={handleSaleRequestSubmit}
              className={`${"bg-[#00c3ff]"} mx-auto text-center text-[#fafafa] rounded-[8px] leading-[32px] px-[16px] text-[14px] font-[700] `}
            >
              Send Request
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReqSalePop;
