import { useContext, useState } from "react";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa6";
import { MyContext } from "../../../App";
import crossIcon from "../../../img/Icons/crossIcon.png";
import premise_sr_01 from "../../../img/sr/premise_sr_01.webp";
import premise_sr_02 from "../../../img/sr/premise_sr_02.webp";
import premise_sr_03 from "../../../img/sr/premise_sr_03.webp";
import premise_sr_04 from "../../../img/sr/premise_sr_04.webp";
import premise_sr_05 from "../../../img/sr/premise_sr_05.webp";
import premise_sr_06 from "../../../img/sr/premise_sr_06.webp";
import premise_sr_07 from "../../../img/sr/premise_sr_07.webp";
import premise_sr_08 from "../../../img/sr/premise_sr_08.webp";
import premise_sr_09 from "../../../img/sr/premise_sr_09.webp";
import premise_sr_10 from "../../../img/sr/premise_sr_10.webp";
import premise_sr_11 from "../../../img/sr/premise_sr_11.webp";
import premise_sr_12 from "../../../img/sr/premise_sr_12.webp";
import premise_sr_13 from "../../../img/sr/premise_sr_13.webp";
import premise_sr_14 from "../../../img/sr/premise_sr_14.webp";

const TestPopup = () => {
  const {
    currentPopup,
    incrementPopup,
    setOpenSequalPop,
    setDoNotShowAgain,
    removeDoNotShowAgain,
    decrementPopup,
  } = useContext(MyContext);

  const [isChecked, setIsChecked] = useState(false);

  const handleNextPopup = () => {
    incrementPopup();
  };
  const handlePrevPopup = () => {
    decrementPopup();
  };

  const handleCheckboxChange = (e) => {
    const isChecked = e.target.checked;
    if (isChecked) {
      setIsChecked(true);
    } else {
      setIsChecked(false);
    }
  };

  const handleClosePopup = () => {
    if (isChecked) {
      incrementPopup();
    }
    setOpenSequalPop(false); // Close the popup in both cases
  };

  // Popup data array
  const popupData = [
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_01.webp`,
      message: "You can read Premise in the language of your choice. ",
      serialNo: 1,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_02.webp`,
      message:
        "You can view the Premises written in a particular language by applying the language filter. ",
      serialNo: 2,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_03.webp`,
      message: "You can sort the Premises from oldest to latest. ",
      serialNo: 3,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_04.webp`,
      message: "You can sort the Premises by Popularity. ",
      serialNo: 4,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_05.webp`,
      message: "You can apply multiple filters simultaneously. ",
      serialNo: 5,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_06.webp`,
      message:
        "You can see only the Premises added by you and shared with you. ",
      serialNo: 6,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_07.webp`,
      message:
        "You can search the Premise by name of the owner or content of the Premise. ",
      serialNo: 7,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_08.webp`,
      message:
        "You can view all Brainstorms on a Premise by clicking on the Premise card. ",
      serialNo: 8,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_09.webp`,
      message:
        "You can view source Premise if the Premise you are viewing is translated from another language. ",
      serialNo: 9,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_10.webp`,
      message: "You can add a new Premise ",
      serialNo: 10,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_11.webp`,
      message:
        "You can filter the Premise Projects available for translations! ",
      serialNo: 11,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_12.webp`,
      message: "You can filter the Premise Projects available for sale! ",
      serialNo: 12,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_13.webp`,
      message: "You can send message to the Premise Project owner! ",
      serialNo: 13,
    },
    {
      imgUrl: `https://uidemos.s3.ap-south-1.amazonaws.com/premise_sr_14.webp`,
      message: "You can view Premise Project owner's profile! ",
      serialNo: 14,
    },

    // Add more popup data here as needed
  ];
  const popupData2 = [
    {
      imgUrl: premise_sr_01,
      message: "You can read Premise in the language of your choice.",
      serialNo: 1,
    },
    {
      imgUrl: premise_sr_02,
      message:
        "You can view the Premises written in a particular language by applying the language filter.",
      serialNo: 2,
    },
    {
      imgUrl: premise_sr_03,
      message: "You can sort the Premises from oldest to latest.",
      serialNo: 3,
    },
    {
      imgUrl: premise_sr_04,
      message: "You can sort the Premises by Popularity.",
      serialNo: 4,
    },
    {
      imgUrl: premise_sr_05,
      message: "You can apply multiple filters simultaneously.",
      serialNo: 5,
    },
    {
      imgUrl: premise_sr_06,
      message:
        "You can see only the Premises added by you and shared with you.",
      serialNo: 6,
    },
    {
      imgUrl: premise_sr_07,
      message:
        "You can search the Premise by name of the owner or content of the Premise.",
      serialNo: 7,
    },
    {
      imgUrl: premise_sr_08,
      message:
        "You can view all Brainstormings on a Premise by clicking on the Premise card.",
      serialNo: 8,
    },
    {
      imgUrl: premise_sr_09,
      message:
        "You can view source Premise if the Premise you are viewing is translated from another language.",
      serialNo: 9,
    },
    {
      imgUrl: premise_sr_10,
      message: "You can add a new Premise",
      serialNo: 10,
    },
    {
      imgUrl: premise_sr_11,
      message:
        "You can filter the Premise Projects available for translations!",
      serialNo: 11,
    },
    {
      imgUrl: premise_sr_12,
      message: "You can filter the Premise Projects available for sale!",
      serialNo: 12,
    },
    {
      imgUrl: premise_sr_13,
      message: "You can send message to the Premise Project owner!",
      serialNo: 13,
    },
    {
      imgUrl: premise_sr_14,
      message: "You can view Premise Project owner's profile!",
      serialNo: 14,
    },
  ];

  // Find the popup data that matches the current popup number
  const currentPopupData = popupData.find(
    (popup) => popup.serialNo === currentPopup
  );

  // If no data is found for the current popup, return null
  if (!currentPopupData) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-[#252525b0] z-[2]">
      <div className="lg:static absolute lg:mt-[90px] bottom-0 bg-white rounded-[12px] w-[100%] lg:w-[623px]">
        <div className="relative rounded-[8px] py-2 xs:py-8 bg-[#fff]">
          <div className="absolute right-[45%] top-[-60px] lg:top-[-17px] lg:right-[-18px]">
            <img
              src={crossIcon}
              onClick={handleClosePopup} // Use the handleClosePopup function here
              alt="close"
              className="w-[40px] h-[40px] z-[9] cursor-pointer"
            />
          </div>

          <div className="flex flex-col justify-center items-center px-2 md:px-8">
            <div className="flex flex-col items-center">
              <img
                src={`https://uidemos.s3.ap-south-1.amazonaws.com/smiley.jpg`}
                alt="Smile doodle"
                className="w-[70px]"
              />
              {/* <h1 className="absolute left-3">{currentPopup}</h1> */}
              <p className="text-center text-[16px] font-medium text-[#00c3ff]">
                Do You Know?
              </p>
            </div>

            <div className="flex flex-col items-center gap-[6px] mb-5 mt-1">
              <h2 className="text-[16px] leading-5 px-4 font-medium text-[#252525] text-center">
                {currentPopupData.message}
              </h2>
              <div className="flex items-center justify-center gap-2">
                <input
                  type="checkbox"
                  id="do-not-show"
                  className="cursor-pointer"
                  onChange={handleCheckboxChange}
                />
                <label
                  htmlFor="do-not-show"
                  className="cursor-pointer text-sm text-gray-700"
                >
                  Do not show this to me again.
                </label>
              </div>

              <img
                src={currentPopupData.imgUrl}
                alt="Popup_Image"
                className="max-w-[230px] w-[90%] shadow rounded-md "
              />
            </div>

            <div className="flex flex-col items-center gap-[6px] mb-2 w-full">
              {currentPopup < 14 ? (
                <div className="flex items-center justify-around w-full">
                  {
                    <button
                      onClick={handlePrevPopup}
                      className={`w-[130px] h-[32px] ${
                        currentPopup === 1
                          ? "bg-[#33b1ca4c] cursor-default"
                          : "bg-[#00c3ff] cursor-pointer"
                      } bg-[#00c3ff] text-white rounded-[8px] px-[12px] text-[14px] font-[600] flex gap-[12px] items-center justify-center`}
                    >
                      <FaArrowLeft />
                      Previous
                    </button>
                  }
                  <button
                    onClick={handleNextPopup}
                    className="w-[130px] h-[32px]  bg-[#00c3ff] text-white rounded-[8px] px-[12px] text-[14px] font-[600] flex gap-[12px] items-center justify-center"
                  >
                    Next
                    <FaArrowRight />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleNextPopup}
                  className="w-[100px] h-[32px]  bg-[#00c3ff] text-white rounded-[8px] px-[12px] text-[14px] font-[600] flex gap-[12px] items-center justify-center"
                >
                  Let's start!
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestPopup;
