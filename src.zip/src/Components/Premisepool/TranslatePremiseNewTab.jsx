// import { useContext, useEffect, useRef, useState } from "react";
// import { toast } from "react-toastify";
// import { fetchUserAccess, MyContext } from "../../App";
// import { useTranslatePremiseMutation } from "../../app/EndPoints/premisePoolApi";
// import transIcon from "../../img/Icons/transIcon.png";
// import NoAccessPopUp from "../PricingModel/NoAccessPopUp";
// import { sortedLanguages } from "./Languages";

// const TranslatePremiseNewTab = ({
//   data,
//   transPopClose,
//   setTransPopClose,
//   setViewText,
//   className,
//   setTransText,
//   transText,
// }) => {
//   const { id, dText, source_language, project_id } = data;

//   const { setSelectedPremiseObj, setSelectedPremiseSpProjectId, currentUser } =
//     useContext(MyContext);

//   const [translatePremise, translateInfo] = useTranslatePremiseMutation();
//   const [selectedOption, setSelectedOption] = useState("");
//   const [transPopup, setTransPopup] = useState(false);
//   // const [transText, setTransText] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [noAccessPopup, setNoAccessPopup] = useState(false);
//   const btnRef = useRef();
//   // console.log("translatePremise", project_id)

//   // console.log("translatePremise", transText);

//   const fetchData = async () => {
//     const body = {
//       text: dText,
//       tar_lang: selectedOption,
//     };

//     setLoading(true);

//     try {
//       const res = await translatePremise(body);
//       if (res?.data?.translated) {
//         // console.log(res?.data?.translated);
//         setTransText(res?.data?.translated);
//         setViewText(res?.data?.translated);
//         setTransPopup(true);
//         setSelectedOption("");
//         setSelectedPremiseSpProjectId(project_id);
//       } else {
//         toast.error("Translation failed", {
//           position: toast.POSITION.TOP_CENTER,
//           autoClose: 800,
//         });
//       }
//     } catch (error) {
//       // console.error("Translation error:", error);
//       toast.error("Translation failed 2", {
//         position: toast.POSITION.TOP_CENTER,
//         autoClose: 800,
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (selectedOption) {
//       fetchData();
//     }
//   }, [selectedOption]);

//   const handleOptionChange = (e) => {
//     setSelectedOption(e.target.value);
//   };

//   useEffect(() => {
//     const closeMenu = (e) => {
//       if (!btnRef?.current?.contains(e.target)) {
//         if (!e.target.closest(".absolute")) {
//           setTransPopClose(null);
//         }
//       }
//     };
//     document.body.addEventListener("mousedown", closeMenu);

//     return () => document.body.removeEventListener("mousedown", closeMenu);
//   }, []);

//   const handleTranslate = async (id) => {
//     const res = await fetchUserAccess(`${currentUser?.id}/PP_Translate`);
//     console.log(`PP_Translate res`, res);
//     if (res?.access === "No") {
//       setNoAccessPopup(res);
//     } else {
//       setTransPopClose(id);
//     }
//   };

//   return (
//     <div ref={btnRef} className="relative">
//       {loading ? (
//         <span className="loading loading-spinner text-[#00c3ff] h-[20px] w-[20px] my-auto "></span>
//       ) : (
//         <img
//           data-te-toggle="tooltip"
//           title="Translate"
//           src={transIcon}
//           // onClick={() => setShowSelectBox(!showSelectBox)}
//           onClick={() => handleTranslate(id)}
//           className={`w-8 h-8 ml-auto cursor-pointer ${className}`}
//           alt=""
//         />
//       )}
//       {transPopClose === id && (
//         <div className="absolute top-[24px] right-0 z-50 w-[135px]  h-[27vh] overflow-x-hidden md:h-[40vh] overflow-y-auto border bg-[#fafafa]">
//           {Object.entries(sortedLanguages)?.map(([key, name]) =>
//             key !== source_language ? (
//               <li
//                 onClick={(e) => {
//                   e.stopPropagation();
//                   setSelectedOption(key);
//                   setTransPopClose(null);
//                 }}
//                 className="cursor-pointer  text-[14px] text-[#252525] hover:bg-[#00c3ff] hover:text-[#fafafa] list-none pl-[8px] border-b"
//                 key={key}
//                 value={key}
//               >
//                 {name}
//               </li>
//             ) : null
//           )}
//         </div>
//       )}
//       {noAccessPopup?.msg === "ShowBecomePrivilege" && (
//         <NoAccessPopUp
//           noAccessPopup={noAccessPopup}
//           setNoAccessPopup={setNoAccessPopup}
//         />
//       )}
//     </div>
//   );
// };

// export default TranslatePremiseNewTab;
import { useContext, useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { fetchUserAccess, MyContext } from "../../App";
import { useTranslatePremiseMutation } from "../../app/EndPoints/premisePoolApi";
import transIcon from "../../img/Icons/transIcon.png";
import NoAccessPopUp from "../PricingModel/NoAccessPopUp";
import { sortedLanguages } from "./Languages";

const TranslatePremiseNewTab = ({
  data,
  transPopClose,
  setTransPopClose,
  setViewText,
  className,
  setTransText,
  transText,
}) => {
  const { id, dText, source_language, project_id } = data;

  const { setSelectedPremiseObj, setSelectedPremiseSpProjectId, currentUser } =
    useContext(MyContext);

  const [translatePremise] = useTranslatePremiseMutation();
  const [selectedOption, setSelectedOption] = useState("");
  const [transPopup, setTransPopup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [noAccessPopup, setNoAccessPopup] = useState(false);
  const btnRef = useRef();

  const fetchData = async () => {
    const body = { text: dText, tar_lang: selectedOption };
    setLoading(true);

    try {
      const res = await translatePremise(body);
      if (res?.data?.translated) {
        setTransText(res?.data?.translated);
        setViewText(res?.data?.translated);
        setTransPopup(true);
        setSelectedOption("");
        setSelectedPremiseSpProjectId(project_id);
      } else {
        toast.error("Translation failed", {
          position: toast.POSITION.TOP_CENTER,
          autoClose: 800,
        });
      }
    } catch (error) {
      toast.error("Translation failed 2", {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 800,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedOption) {
      fetchData();
    }
  }, [selectedOption]);

  useEffect(() => {
    const closeMenu = (e) => {
      if (!btnRef?.current?.contains(e.target)) {
        if (!e.target.closest(".absolute")) {
          setTransPopClose(null);
        }
      }
    };
    document.body.addEventListener("mousedown", closeMenu);
    return () => document.body.removeEventListener("mousedown", closeMenu);
  }, []);

  const handleTranslate = async (id) => {
    const res = await fetchUserAccess(`PP_Translate`);
    if (res?.has_access === false) {
      setNoAccessPopup(res);
    } else {
      setTransPopClose(id);
    }
  };

  // ✅ handle both desktop li click & mobile select change
  const handleLanguageSelect = async (lang) => {
    const res = await fetchUserAccess(`PP_Translate`);
    if (res?.has_access === false) {
      setNoAccessPopup(res);
      return;
    }
    setSelectedOption(lang);
    setTransPopClose(null);
  };

  return (
    <div ref={btnRef} className="relative">
      {loading ? (
        <span className="loading loading-spinner text-[#00c3ff] h-[20px] w-[20px] my-auto "></span>
      ) : (
        <>
          {/* ✅ Desktop (icon + dropdown) */}
          <div className="lgVisible">
            <img
              data-te-toggle="tooltip"
              title="Translate"
              src={transIcon}
              onClick={() => handleTranslate(id)}
              className={`w-8 h-8 ml-auto cursor-pointer ${className}`}
              alt="translate"
            />

            {transPopClose === id && (
              <div className="absolute top-[24px] right-0 z-50 w-[135px] h-[27vh] overflow-x-hidden md:h-[40vh] overflow-y-auto border bg-[#fafafa]">
                {Object.entries(sortedLanguages)?.map(([key, name]) =>
                  key !== source_language ? (
                    <li
                      key={key}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLanguageSelect(key);
                      }}
                      className="cursor-pointer text-[14px] text-[#252525] hover:bg-[#00c3ff] hover:text-[#fafafa] list-none pl-[8px] border-b"
                    >
                      {name}
                    </li>
                  ) : null
                )}
              </div>
            )}
          </div>

          {/* ✅ Mobile (icon + invisible select overlay) */}
          <div className="lgFlxHidden relative p-1 rounded-[4px]  items-center justify-center">
            <img
              data-te-toggle="tooltip"
              title="Translate"
              src={transIcon}
              className="w-[22px] h-[22px] pointer-events-none"
              alt="translate"
            />

            <select
              className="absolute inset-0 opacity-0 cursor-pointer"
              defaultValue=""
              onChange={(e) => handleLanguageSelect(e.target.value)}
            >
              <option value="" disabled></option>
              {Object.entries(sortedLanguages)?.map(([key, name]) =>
                key !== source_language ? (
                  <option key={key} value={key}>
                    {name}
                  </option>
                ) : null
              )}
            </select>
          </div>
        </>
      )}

      {noAccessPopup?.msg === "ShowBecomePrivilege" && (
        <NoAccessPopUp
          noAccessPopup={noAccessPopup}
          setNoAccessPopup={setNoAccessPopup}
        />
      )}
    </div>
  );
};

export default TranslatePremiseNewTab;
