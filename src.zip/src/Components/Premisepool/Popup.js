
// Popup.jsx
// Main popup component for displaying a premise with its details, comments, replies, and various actions.
// Handles opening/closing the popup, fetching premise data, comments, user info, and managing multiple modals/popups.
// Integrates character editing, translation, monetization, sale requests, and reply handling.
// Uses several child components for specific sections (comments, like, AskIda, text display, etc.).

// PopupPremiseText.jsx
// Renders the main premise text inside the popup, including background image/color and text stylings.
// Handles proper display of premise content (dText and viewText) with formatting options.

// PopupComment.jsx
// Shows comment icon/button to open the comment field in the popup.
// Handles toggling the comment input area.

// PopupTextarea.jsx
// Textarea input for submitting new comments or replies on a premise.
// Supports controlled input, character counting, and integrates with reply handling.

// CommentList.jsx
// Displays the list of comments for a premise, including nested replies.
// Handles opening replies, setting reply IDs, loading states, and passing necessary callbacks.

// LikePremise.jsx
// Handles the like functionality for a premise, including popup animation and state management.
// Updates premise likes and interacts with parent `Popup` for refetching data.

// AskIda.jsx
// Renders a special "Ask Ida" feature in the popup for user interaction or AI suggestions.
// Positioned both in mobile and desktop layouts.

// CharacterEditablePop.jsx
// Popup for viewing and editing characters associated with the premise.
// Allows saving changes, marking draft/active status, and refetching updated data.

// DeletePremise.jsx
// Modal to confirm deletion of a premise.
// Uses project/premise ID and triggers a refetch after successful deletion.

// CardHeadOptions.jsx
// Component that renders the top-right "options" menu for a premise card in the popup.
// Handles translation requests, sale requests, hiding/unhiding, monetization, and other dynamic actions.

// UserType.jsx
// Displays the type of a user (central database type and user_type) next to the user's name.

// TransInOtherLang.pop.jsx
// Popup for showing translations of the premise in other languages.

// Popup-specific alert/popups
// AvailableForTranslationPop, BankDetailsPop, MonetizePreferencePop, PaySalePopup,
// ReqSalePop, ReqTranslationPop, NoPremisePop, NotifyPopup, SaleRequestedOwner, ViewTranslationPop
// These handle specialized actions or alerts related to the premise (sale, translation, bank info, etc.).





import { useContext, useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
// import { IoMdSend } from "react-icons/io";
import {
    useGetCommentByPremiseIdQuery,
    useGetOnePremiseQuery,
    useGetPremiseUserPictureQuery,
    useGetPremiseUserQuery,
} from "../../app/EndPoints/premisePoolApi";
import crossIcon from "../../img/Icons/crossIcon.png";
import newTabIcn from "../../img/Icons/newTabIcn.png";
import userImg from "../../img/Icons/userImg.png";
// import transCartQ from "../../../img/Icons/transCartQ.png";

// import backgroundImg from "../../img/Icons/download.jpg";
import { MdKeyboardBackspace } from "react-icons/md";
import { MyContext } from "../../App";
import {
    useGetSavedCharactersQuery,
    useSaveCharactersMutation,
} from "../../app/EndPoints/Characters/Characters";
import { useCreateReplyMutation } from "../../app/EndPoints/commentReply/reply";

import axios from "axios";
import CardHeadOptions from "../PremiseV2/Card/CardHeadOptions";
import AvailableForTranslationPop from "../PremiseV2/Popups/AvailableForTranslationPop";
import BankDetailsPop from "../PremiseV2/Popups/BankDetails/BankDetailsPop";
import MonetizePreferencePop from "../PremiseV2/Popups/MonetizePreferencePop";
import PaySalePopup from "../PremiseV2/Popups/PaySalePopup";
import ReqSalePop from "../PremiseV2/Popups/ReqSalePop";
import ReqTranslationPop from "../PremiseV2/Popups/ReqTranslationPop";

import NoPremisePop from "../PremiseV2/Popups/alerts/NoPremisePop";
import NotifyPopup from "../PremiseV2/Popups/alerts/NotifyPopup";
import SaleRequestedOwner from "../PremiseV2/Popups/SaleRequestedOwner";
import TransInOtherLang from "../PremiseV2/Popups/TransInOtherLang.pop";
import ViewTranslationPop from "../PremiseV2/Popups/ViewTranslation.pop";
import AddBeatTutorialPop from "../PremiseV2/sequalPopup/AddBeatTutorialPop";
import AfterFinalPostPremisePop from "../PremiseV2/sequalPopup/AfterFinalPostPremisePop";
import NoAccessLbPopUp from "../PricingModel/NoAccessLbPopUp";
import NoAccessPopUp from "../PricingModel/NoAccessPopUp";
import AskIda from "../SharedVersion/AskIda";
import PopupComment from "../SharedVersion/PopupComment";
import PopupPremiseText from "../SharedVersion/PopupPremiseText";
import PopupTextarea from "../SharedVersion/PopupTextarea";
import TypingLoader from "../TypingLoader";
import { baseURL, URL } from "../utils";
import CharacterEditablePop from "./Character/CharacterEditablePop";
import CommentList from "./CommentList";
import DeletePremise from "./DeletePremise";
import LikePopup from "./LikePopup";
import LikePremise from "./LikePremise";
import OwnerMail from "./OwnerMail";
import { hideUnhidePremise } from "./PreiseUtils";
import "./Premise.css";
import UserMail from "./UserMail";
import UserNamePopup from "./UserNamePopup";
import UserType from "./UserType";

const Popup = ({
  popClose,
  data,
  refetch,
  transText,
  viewText,
  handleVisibility,
  handleMonetizing,
  afterFinalPostPremiseDemoPop,
  setAfterFinalPostPremiseDemoPop,
}) => {
  const {
    bg_img,
    bg_color,
    stylings,
    dText,
    id,
    user,
    premiseOwner,
    handleUserMail,
    formattedTime,
    formattedDate,
    setHideDisable,
    project_id,
  } = data;
  // console.log("popData", data);
  const {
    data: characters,
    refetch: charRefetch,
    isCharLoading,
  } = useGetSavedCharactersQuery(project_id);
  const [notifyPopup, setNotifyPopup] = useState(false);
  const [saveCharacter, savedCharInfo] = useSaveCharactersMutation();

  const [characterArray, setCharacterArray] = useState([]);
  const [addPopup, setAddPopup] = useState(null);
  const [onlyAdd, setOnlyAdd] = useState(true);
  const [characterLoading, setCharacterLoading] = useState(true);

  const [openTransOtherPop, setOpenTransOtherPop] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [openAvailableForTranslationPop, setOpenAvailableForTranslationPop] =
    useState(false);
  const [openMonetizingPreferencesPop, setOpenMonetizingPreferencesPop] =
    useState(null);
  const [openViewTranslationsPop, setOpenViewTranslationsPop] = useState(false);
  const [noAccessLbPopUp, setNoAccessLbPopUp] = useState(null);
  const [saleId, setSaleId] = useState("");
  const [viewSale, setViewSale] = useState(false);
  const [saleRequestPop, setSaleRequestPop] = useState("");
  const [openPop, setOpenPop] = useState(false);
  const [userMail, setUserMail] = useState(null);
  const [ownerMail, setOwnerMail] = useState(false);
  const [openHidePop, setOpenHidePop] = useState(null);

  const [service, setService] = useState(null);
  const [noAccessPopup, setNoAccessPopup] = useState(null);

  useEffect(() => {
    if (characters) setCharacterArray(characters);
  }, [characters]);

  const handleUpdateSavedChar = async () => {
    setCharacterLoading(true);
    try {
      characterArray.forEach((character) => {
        if (character.is_ai_generated === undefined) {
          character.is_ai_generated = false;
        }
      });
      const charArr = JSON.stringify(characterArray);
      const data = {
        // id: premiseID,
        id: project_id,
        // body: { char_data: charArr },
        body: { char_data: charArr, is_draft: false, premise_id: id },
      };

      const response = await saveCharacter(data);

      if (response) {
        // setAddNewCharacter(false)
        // setEditPopupOpen(false)
        // setCharSaveDisable(true);
        setCharacterLoading(false);
        setOpenCharacterChart(false);
        charRefetch();

        // toast.success("characters updated!")
      }
      return response;
    } catch (error) {
      setCharacterLoading(false);
      // console.error("Error updating characters:", error);
    }
  };

  const handleSaveAsDraft = async () => {
    setCharacterLoading(true);
    try {
      characterArray.forEach((character) => {
        if (character.is_ai_generated === undefined) {
          character.is_ai_generated = false;
        }
      });
      const charArr = JSON.stringify(characterArray);
      const data = {
        // id: premiseID,
        id: project_id,
        body: { char_data: charArr, is_draft: true, premise_id: id },
        is_draft: true,
      };

      const response = await saveCharacter(data);

      if (response) {
        // setAddNewCharacter(false)
        // setEditPopupOpen(false)
        setOpenCharacterChart(false);
        // setCharSaveDisable(true);
        setCharacterLoading(false);
        popClose();

        // toast.success("characters updated!")
      }
      return response;
    } catch (error) {
      setCharacterLoading(false);
      // console.error("Error updating characters:", error);
    }
  };
  const lastCommentRef = useRef(null);

  const replyRef = useRef(null);

  const {
    allspProjectJSON,
    currentlyOpenedCommentID,
    setCurrentlyOpenedCommentID,
  } = useContext(MyContext);
  const [openDotMenu, setOpenDotMenu] = useState(false);
  const [isDelete, setIsDelete] = useState(false);
  const [loading, setLoading] = useState(true);

  const [commentField, setCommentField] = useState(true);
  const [replyField, setReplyField] = useState(false);

  const [cValue, setCvalue] = useState(null);

  const [openReplyField, setOpenReplyField] = useState(null);
  const [replyLoading, setReplyLoading] = useState(false);
  const [replyToCommentID, setReplyToCommentID] = useState(null);
  const [openReplyFieldID, setOpenReplyFieldID] = useState(null);
  const [commentOwner, setCommentOwner] = useState("");

  const [openAllReplies, setOpenAllReplies] = useState(false);
  const [replyText, setReplyText] = useState("");

  const [createReplyMutation, isReplyResInfo] = useCreateReplyMutation();
  const replyResStat = isReplyResInfo?.status;
  const [openCharacterChart, setOpenCharacterChart] = useState(null);

  const [replyTextCount, setReplyTextCount] = useState(0);
  const [likePopup, setLikePopup] = useState(false);
  const handleClear = () => {
    // setText("");
  };

  const currentProjectData = allspProjectJSON?.projects?.find(
    (item) => item.pro_uuid === project_id
  );
  // console.log("ALLPROJECT", project_id);

  const currentProjectName = currentProjectData?.name;
  const isProjectLocked = currentProjectData?.locked;
  const currentProjectOwner = currentProjectData?.owner;

  const {
    data: profileImg,
    profileImgLoading,
    refetch: profileRefetch,
  } = useGetPremiseUserPictureQuery(premiseOwner?.id);

  const proImgUrl = baseURL.concat(profileImg?.[0]?.profile_photo);
  console.log("user", user);

  const { boldStyle, italicStyle, underlineStyle, hexColor } = stylings;
  const premiseId = data?.id;

  const {
    data: premiseData,
    isPremiseLoading,
    refetch: premiseRefetch,
  } = useGetOnePremiseQuery(premiseId);
  // console.log("premiseId", premiseData?.available_for_sale);
  const [actOneThreshold, setActOneThreshold] = useState(null);
  const [actTwoEnd, setActTwoEnd] = useState(null);

  // console.log("premiseData?.visible_to",premiseData?.visible_to)

  useEffect(() => {
    if (!isPremiseLoading && premiseData?.setC) {
      // Step 1: Log premiseData.setC to verify it
      // console.log("premiseData setC:", premiseData?.setC); // Check what setC looks like

      try {
        const setCString = premiseData?.setC;

        // Step 2: Check if setC is already an object or a string
        if (typeof setCString === "string") {
          const setCObject = JSON.parse(setCString.replace(/'/g, '"')); // Parse if it's a string
          // console.log("Parsed setCObject:", setCObject); // Log parsed object to ensure it's correct

          const actOne = setCObject["Forward the Act One"];
          const actTwo = setCObject["Forward the Act Two"];

          // Step 3: Set the thresholds
          setActOneThreshold(actOne); // Last number of Act One
          setActTwoEnd(actTwo[actTwo.length - 1]); // Last number of Act Two

          // console.log("actOneThreshold:", actOne); // Check if actOneThreshold is being set correctly
          // console.log("actTwoEnd:", actTwo[actTwo.length - 1]); // Check if actTwoEnd is being set correctly
        } else {
          // If setC is already an object, handle it directly
          const setCObject = setCString; // No need to parse;

          const actOne = setCObject["Forward the Act One"];
          const actTwo = setCObject["Forward the Act Two"];

          setActOneThreshold(actOne[actOne.length - 1]); // Last number of Act One
          setActTwoEnd(actTwo[actTwo.length - 1]); // Last number of Act Two
        }
      } catch (error) {
        console.error("Error parsing setC or setting thresholds:", error);
      }
    }
  }, [isPremiseLoading, premiseData]); // Ensure premiseData is available before running the effect

  useEffect(() => {}, [actOneThreshold, actTwoEnd]);

  useEffect(() => {
    premiseRefetch();
  }, [premiseId]);

  const {
    data: commentsData,
    isCommentLoading,
    refetch: commentRefetch,
  } = useGetCommentByPremiseIdQuery(premiseId);

  const finalCount = commentsData?.counts;

  const handleDelete = (id) => {
    setIsDelete(id);
  };

  const { data: userQuery, isUserLoading } = useGetPremiseUserQuery();

  const userName = `${userQuery?.first_name} ${userQuery?.last_name}`;
  const userFirstName = userQuery?.first_name;
  const userLastName = userQuery?.last_name;

  // useEffect(() => {
  //   setCvalue(parseInt(commentsData?.comments?.length) + 1);
  // }, [commentsData]);

  useEffect(() => {
    if (commentsData) {
      setLoading(false);
    }
  }, [commentsData]);

  useEffect(() => {
    // console.log(commentsData.comments.length);
    commentRefetch();
    const commentArray = commentsData?.comments?.length + 1;

    setCvalue(commentArray);
  }, [commentsData, commentRefetch]);

  const handleReplyTextChange = (event) => {
    const reply = event?.target?.value?.replace(/^\s+|\s+(?=\s)/g, "");
    // console.log("reply----->", reply);
    setReplyTextCount(reply.length);
    setReplyText(reply);
  };

  //submit reply
  const handlePostReplyToComment = async (e) => {
    e.preventDefault();
    setReplyLoading(true);
    const data = {
      reply: replyToCommentID,
      text: replyText,
    };
    const response = await createReplyMutation(data);
    if (response) {
      // refetch();
      // setOpenReplyField(null);
      e.target.reset();
      setReplyText("");
      commentRefetch();
      toast.success("Reply added!", {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 800,
      });
      setReplyLoading(false);
    }
  };
  // useEffect(() => {}, [openDotMenu]);

  const handleHideUnhidePremise = (id) => {
    hideUnhidePremise(id, setHideDisable, premiseRefetch, setOpenDotMenu);
  };

  const dotPopupRef = useRef();
  useEffect(() => {
    const closeMenu = (e) => {
      if (
        openDotMenu !== null && // Only close if a menu is open
        !dotPopupRef?.current?.contains(e.target) && // Allow clicks inside the dot menu
        !e.target.closest(".ellipsis-container") // Allow clicks inside the button
      ) {
        setOpenDotMenu(null);
      }
    };

    document.body.addEventListener("mousedown", closeMenu);
    return () => document.body.removeEventListener("mousedown", closeMenu);
  }, [openDotMenu]);

  // console.log("commentsData", commentsData);
  const handleOpenSp = () => {
    // console.log("object", p);
    if (isProjectLocked) {
      window.open(`${baseURL}/scriptpad/#/generated-scripts`);
    }
    window.open(
      `${baseURL}/scriptpad/#/${project_id}/0x0d2a90b8da670ddad09e2d7b719779a41687515aa196cb35568f20659b204de6/premise`
    );
  };

  // dynamic setup conflict resolution
  const [headerText, setHeaderText] = useState("Setup");
  const commentsRef = useRef(null);

  useEffect(() => {}, [openDotMenu]);

  const handlePremiseOpenNewTab = (id) => {
    // let host = window.location.origin + `/#/new-tab/${id}`;
    // window.open(host, "_blank");

    // console.log(id);
    // // const url = `${baseURL}/new-tab/${id}`; // Use `id` if provided; fallback to current page URL
    const url = `${window.location.origin}/brainstorm/#/new-tab/${id}`; // Use `id` if provided; fallback to current page URL

    // // Open the URL in a new tab
    window.open(url, "_blank");
  };

  const [translationRequestPop, setTranslationRequestPop] = useState("");

  const [viewTrnRequests, setViewTrnRequests] = useState("");
  const [viewSaleRequests, setViewSaleRequests] = useState("");

  const handleTranslationRequest = (id) => {
    setTranslationRequestPop(id);
    // console.log("trans id", id);
  };

  const [viewTransactionPId, setViewTransactionPId] = useState("");
  const handleViewTransaction = (id) => {
    // console.log(id);
    setViewTransactionPId(id);
    setOpenViewTranslationsPop(!openViewTranslationsPop);
    setOpenDotMenu(null);
  };

  const token = localStorage.getItem("accessToken");

  const header = {
    Authorization: `Bearer ${token}`,
    Accept: "application/json",
    "Content-Type": "application/json",
  };
  const [saleRequestedOwner, setSaleRequestedOwner] = useState(true);
  const [names, setNames] = useState([]);
  const handleSaleRequestedOwner = async () => {
    try {
      // console.log(id);
      const data = await axios.get(
        `${URL}/brainstorm/premise/request/${id}/Sale`,
        {
          headers: header,
        }
      );

      if (data?.data?.data?.length > 0) {
        setSaleRequestedOwner(true);
      }

      setNames((prevNames) => [data]);
    } catch (error) {
      console.log(error);
    }
  };

  const handleOpenAllReplies = (id, commenterName) => {
    console.log("Open replyfield");
    setOpenAllReplies(true);
    setOpenReplyFieldID(id);
    setReplyToCommentID(id);
    // setReplyToCommentID(comments?.id);
    // setCurrentlyOpenedCommentID(comments?.id);
    setCurrentlyOpenedCommentID(id);
    setCommentOwner(commenterName);
  };

  const [openPopSource, setOpenPopSource] = useState(false);
  const [addBeatTutorialPop, setAddBeatTutorialPop] = useState(false);
  const [sourcePremiseNotAvailabl, setSourcePremiseNotAvailable] =
    useState(false);
  const [sourcePopData, setSourcePopData] = useState();
  const handleCheckPremiseData = async (id) => {
    try {
      const data = await axios.get(`${URL}/brainstorm/api/v2/premise/${id}`, {
        headers: header,
      });
      const premiseData = data?.data;
      setSourcePopData("premiseData", premiseData);

      if (premiseData) {
        if (premiseData?.hidden && premiseData?.premiseOwner?.id !== user) {
          setSourcePremiseNotAvailable(true);
          return;
        }
        const formattedDate = new Date(
          premiseData?.created_at
        ).toLocaleDateString("en-US", {
          // timeZone: "GMT",
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          // weekday: "short",
          day: "numeric",
          month: "short",
          year: "numeric",
        });
        const formattedTime = new Date(
          premiseData?.created_at
        ).toLocaleTimeString("en-US", {
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          hour: "numeric",
          minute: "numeric",
        });

        const data = {
          stylings: premiseData?.text?.includes("+")
            ? JSON.parse(premiseData?.text?.split("+")[0])
            : {}, // Default to an empty object if `text` is undefined or improperly formatted
          bg_color: premiseData?.bg_color || "",
          premiseOwner: premiseData?.premiseOwner,
          bg_img: premiseData?.bg_img || "",
          comments: premiseData?.comments || [],
          created_at: premiseData?.created_at || "",
          likes: premiseData?.likes || 0,
          id: premiseData?.id || "",
          source_language: premiseData?.source_language || "",
          updated_at: premiseData?.updated_at || "",
          dText: premiseData?.text?.includes("+")
            ? premiseData?.text?.split("+")[1]
            : "",
          // viewText: premiseData?.text?.includes("+")
          //   ? premiseData?.text?.split("+")[1]
          //   : "",
          project_id: premiseData?.project_id || "",
          m_value: premiseData?.m_value || "",
          formattedTime,
          formattedDate,
          user,
        };

        setSourcePopData(data);
      }

      if (premiseData?.premiseOwner?.id === user) {
        handlePremiseOpenNewTab(premiseData?.id);
      } else {
        setOpenPopSource(true);
      }
    } catch (error) {
      setSourcePremiseNotAvailable(true);
    }
  };

  if (isPremiseLoading) {
    return <>Loading...</>;
  } else
    return (
      <div className="fixed top-0 left-0 w-full h-full flex items-center mt-[80px] lg:mt-[0px] bg-[#252525b0] justify-center z-[1] ">
        {/*{/* <ToastContainer /> */}
        <div className=" h-[97vh] lg:h-auto lg:mt-[88px] mb-[20px] lg:mb-0 2xl:h-[673px] xl:mt-[85px] w-full bg-[#fff] lg:bg-[#FAFAFA]  lg:w-[1090px] xl:w-[1220px] md:mx-auto relative lg:rounded-[8px] ">
          {/* close popup */}
          <img
            src={crossIcon}
            alt=""
            className="text-red-500 w-8 h-8 top-[-15px] right-[-15px] absolute z-[1] m-1 cursor-pointer lgVisible  "
            onClick={() => {
              popClose(false);
              refetch();
            }}
          />
          <MdKeyboardBackspace
            src={crossIcon}
            alt=""
            className="text-[#252525] text-left text-[32px] my-[8px] mt-5 ml-[24px] z-[1] cursor-pointer lgHidden"
            onClick={() => {
              popClose(false);
              // setOpenReplyField(null);
              // setReplyToCommentID(null);
              //sdfdsfds
            }}
          />

          <div
            className="flex flex-col lg:flex-row lg:justify-center 
                gap-3 lg:gap-[16px] xl:gap-[32px] 
                h-[calc(94vh-230px)] md:h-[calc(100vh-301px)] lg:h-[calc(100vh-101px)]  lg:max-h-[554px] xl:h-[677px] 2xl:max-h-[674px]
                max-h-[100vh] overflow-hidden "
          >
            {/* left div */}
            <div
              className=" border border-[#00c3ff] lg:border-[#eaeaea]  flex-shrink-0 w-[94%] sm:w-[80%] lg:w-[33%] 
                max-w-[377px] mx-auto rounded-lg h-[28vh] lg:h-auto 
               overflow-hidden lg:shadow-lg lg:my-4 xl:my-8 lg:ml-4"
            >
              {/* header */}
              <div className="flex justify-between items-center bg-[#FAFAFA] rounded-t-[8px] px-2 sm:px-[15px] py-[6px] mt-[1px]">
                <div className="">
                  {/* <a
                    target="_blank"
                    rel="noreferrer"
                    href={
                      premiseOwner?.id === user
                        ? `${URL}/memberpage/#/personaldetails`
                        : `${URL}/memberpage/#/user/${premiseOwner?.id}/personaldetails`
                    }
                  >
                    <div className="flex-1 flex gap-1 items-start">
                      {profileImg?.[0]?.profile_photo ? (
                        <img
                          src={proImgUrl}
                          className="h-[35.9px] min-w-[36px] rounded-full object-cover border border-[#eaeaea]"
                          alt=""
                        />
                      ) : (
                        <img
                          src={userImg}
                          className="w-[36px] h-[35.9px] rounded-full border border-[#eaeaea]"
                          alt=""
                        />
                      )}
                      <div>
                        <div className="flex items-center">
                          <h4
                            className={`notranslate w-[75px] max-w-[110px] text-[#252525] font-[500] text-[16px] capitalize cursor-pointer hover:text-[#00c3ff] truncate `}
                            title={`${premiseOwner?.first_name} ${premiseOwner?.last_name}`}
                          >
                            {premiseOwner?.first_name} {premiseOwner?.last_name}
                          </h4>
                          <UserType
                            type={premiseOwner?.centraldatabase?.type}
                            user_type={premiseOwner?.centraldatabase?.user_type}
                          />
                        </div>
                        <p className="text-[#616161] text-[12px] flex flex-col font-[400] leading-[12px] min-w-[130px] mt-[-3px]">
                          <p>
                            {formattedDate}, {formattedTime}
                          </p>
                          {(premiseOwner?.id === user ||
                            premiseOwner?.id === currentProjectOwner) && (
                            <p
                              data-te-toggle="tooltip"
                              title={`${`${currentProjectName} `}`}
                              className="notranslate"
                            >
                          
                              {currentProjectName?.length > 20
                                ? `${currentProjectName.slice(0, 20)}...`
                                : currentProjectName}
                            </p>
                          )}
                        </p>
                      </div>
                    </div>
                  </a> */}
                  <div className="flex-1 flex gap-1 items-start">
                    {/* ✅ Clickable image */}
                    <a
                      target="_blank"
                      rel="noreferrer"
                      href={
                        premiseOwner?.id === user
                          ? `${URL}/memberpage/#/personaldetails`
                          : `${URL}/memberpage/#/user/${premiseOwner?.id}/personaldetails`
                      }
                    >
                      {profileImg?.[0]?.profile_photo ? (
                        <img
                          src={proImgUrl}
                          className="h-[35.9px] w-[36px] rounded-full object-cover border border-[#eaeaea] cursor-pointer"
                          alt=""
                        />
                      ) : (
                        <img
                          src={userImg}
                          className="w-[36px] h-[35.9px] rounded-full border border-[#eaeaea] cursor-pointer"
                          alt=""
                        />
                      )}
                    </a>

                    <div className="block max-w-[140px]">
                      <div className="flex items-center">
                        {/* ✅ Clickable name */}
                        <a
                          target="_blank"
                          rel="noreferrer"
                          href={
                            premiseOwner?.id === user
                              ? `${URL}/memberpage/#/personaldetails`
                              : `${URL}/memberpage/#/user/${premiseOwner?.id}/personaldetails`
                          }
                        >
                          <h4
                            className={`notranslate w-[99px] max-w-[110px] text-[#252525] font-[500] text-[16px] capitalize cursor-pointer hover:text-[#00c3ff] truncate`}
                            title={`${premiseOwner?.first_name} ${premiseOwner?.last_name}`}
                          >
                            {premiseOwner?.first_name} {premiseOwner?.last_name}
                          </h4>
                        </a>

                        <UserType
                          type={premiseOwner?.centraldatabase?.type}
                          user_type={premiseOwner?.centraldatabase?.user_type}
                        />
                      </div>

                      <p className="text-[#616161] text-[12px] flex flex-col font-[400] leading-[12px] min-w-[130px] mt-[-3px]">
                        <p>
                          {formattedDate}, {formattedTime}
                        </p>
                        {(premiseOwner?.id === user ||
                          premiseOwner?.id === currentProjectOwner) && (
                          <p
                            data-te-toggle="tooltip"
                            title={`${`${currentProjectName} `}`}
                            className="notranslate"
                          >
                            {currentProjectName?.length > 20
                              ? `${currentProjectName.slice(0, 19)}...`
                              : currentProjectName}
                          </p>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-[3px] items-center">
                  {premiseOwner?.id === user && (
                    <img
                      data-te-toggle="tooltip"
                      title="Open In New Tab"
                      src={newTabIcn}
                      className="w-7 h-7 cursor-pointer mt-[-8px]"
                      alt=""
                      onClick={() => handlePremiseOpenNewTab(premiseId)}
                    />
                  )}
                  <CardHeadOptions
                    // owner={owner}
                    // index={index}

                    refetch={premiseRefetch}
                    viewTrnRequests={viewTrnRequests}
                    setViewTrnRequests={setViewTrnRequests}
                    viewTransactionPId={viewTransactionPId}
                    setViewTransactionPId={setViewTransactionPId}
                    setViewSaleRequests={setViewSaleRequests}
                    openTransOtherPop={openTransOtherPop}
                    setOpenTransOtherPop={setOpenTransOtherPop}
                    handleDelete={handleDelete}
                    setOpenCharacterChart={setOpenCharacterChart}
                    openViewTranslationsPop={openViewTranslationsPop}
                    openAvailableForTranslationPop={
                      openAvailableForTranslationPop
                    }
                    setOpenAvailableForTranslationPop={
                      setOpenAvailableForTranslationPop
                    }
                    setOpenViewTranslationsPop={setOpenViewTranslationsPop}
                    setOpenMonetizingPreferencesPop={
                      setOpenMonetizingPreferencesPop
                    }
                    setNoAccessLbPopUp={setNoAccessLbPopUp}
                    // setUserMail={setUserMail}
                    setSaleId={setSaleId}
                    setViewSale={setViewSale}
                    setSaleRequestPop={setSaleRequestPop}
                    setTranslationRequestPop={setTranslationRequestPop}
                    isProjectLocked={isProjectLocked}
                    id={id}
                    premiseOwner={premiseOwner}
                    filter_flag={premiseData?.filter_flag}
                    visible_to={premiseData?.visible_to}
                    comment_filter_flag={premiseData?.comment_filter_flag}
                    project_id={project_id}
                    available_for_sale={premiseData?.available_for_sale}
                    available_for_translation={
                      premiseData?.available_for_translation
                    }
                    premise_source_id={premiseData?.premise_source_id}
                    translation_request_count={
                      premiseData?.translation_request_count
                    }
                    no_of_times_translated={premiseData?.no_of_times_translated}
                    sale_request_count={premiseData?.sale_request_count}
                    is_requested_for_sale={premiseData?.is_requested_for_sale}
                    is_translated_languages={
                      premiseData?.is_translated_languages
                    }
                    dotPopupRef={dotPopupRef}
                    setOpenDotMenu={setOpenDotMenu}
                    openDotMenu={openDotMenu}
                    setOpenHidePop={setOpenHidePop}
                    openHidePop={openHidePop}
                    setUserMail={setUserMail}
                    addPopup={addPopup}
                    setAddPopup={setAddPopup}
                    PremiseData={premiseData}
                    premiseRefetch={premiseRefetch}
                    notifyPopup={notifyPopup}
                    setNotifyPopup={setNotifyPopup}
                    is_read_only={premiseData?.is_read_only}
                    handleCheckPremiseData={handleCheckPremiseData}
                    fromPopup={true}
                  />
                </div>
              </div>
              {/* image */}
              <PopupPremiseText
                {...{ data, bg_img, bg_color, stylings, viewText, dText }}
              />

              <div className="hidden md:flex  mt-[8px]  flex-col justify-between">
                {/* <div className="w-[90%] mx-auto bg-[#eaeaea] h-[2px] hidden md:block" /> */}
                {/* icons */}
                <div className="lg:ml-3 hidden lg:block py-[2px] ">
                  <div className=" flex gap-1 space-x-4 items-center px-3 ">
                    {/* like */}
                    {/* <PopupLike
                     {...{ user, id, premiseRefetch, premiseData }} 
                     /> */}

                    <LikePremise
                      data={{
                        user,
                        ...premiseData,
                        likePopup,
                        setLikePopup,
                      }}
                      refetch={premiseRefetch}
                    />
                    {/* comment */}
                    <PopupComment
                      {...{
                        setOpenReplyField,
                        setCommentField,
                        commentField,
                        finalCount,
                      }}
                    />
                  </div>
                </div>{" "}
              </div>
              <div className="hidden lg:block mt-10 lg:mt-4 xl:mt-10 w-full">
                <div className="flex gap-1 items-center w-[54%] mt-[-18px] mx-auto">
                  <AskIda
                    id={premiseId}
                    source_language={premiseData?.source_language}
                    {...{
                      user,
                      premiseOwner,
                      commentRefetch,
                      setOpenAllReplies,
                      setOpenReplyFieldID,
                      lastCommentRef,
                      isLoading,
                      setIsLoading,
                      setNoAccessPopup,
                      setService,
                    }}
                  />{" "}
                  <h3>or,</h3>
                </div>
                {/* textarea */}
                <PopupTextarea
                  {...{
                    premiseOwner,
                    user,
                    premiseId,
                    commentRefetch,
                    setOpenAllReplies,
                    setOpenReplyFieldID,
                    lastCommentRef,
                    commentField,
                    setCommentField,
                    setReplyField,
                    replyField,
                    replyRef,
                    isLoading,
                    setIsLoading,
                  }}
                />
              </div>
            </div>

            {/* right div */}
            <div
              className="flex-1 w-[97%] sm:w-[68%] md:w-[88%] lg:w-[769px] 
                mx-auto lg:ml-0 
                bg-white lg:bg-[#fafafa] border border-[#eaeaea] lg:shadow-lg
                rounded-[8px] flex flex-col overflow-hidden lg:my-4 xl:my-8 lg:mr-4"
            >
              {/* all comments component */}
              <div
                ref={lastCommentRef}
                className="flex-1 overflow-y-auto px-2 pt-3 pb-12"
              >
                {loading ? (
                  <div className="z-[1] lg:mt-[160px] xl:mt-[200px]">
                    <TypingLoader />
                  </div>
                ) : commentsData?.comments?.length > 0 ? (
                  <CommentList
                    comments={commentsData.comments}
                    handleOpenAllReplies={handleOpenAllReplies}
                    data={data}
                    refetch={refetch}
                    openReplyField={openReplyField}
                    setOpenReplyField={setOpenReplyField}
                    replyToCommentID={replyToCommentID}
                    setReplyToCommentID={setReplyToCommentID}
                    replyResStat={replyResStat}
                    setCommentOwner={setCommentOwner}
                    setOpenAllReplies={setOpenAllReplies}
                    openAllReplies={openAllReplies}
                    commentRefetch={commentRefetch}
                    proImgUrl={proImgUrl}
                    setReplyField={setReplyField}
                    replyField={replyField}
                    handleReplyTextChange={handleReplyTextChange}
                    handlePostReplyToComment={handlePostReplyToComment}
                    replyLoading={replyLoading}
                    premiseData={premiseData}
                    replyTextCount={replyTextCount}
                    setReplyTextCount={setReplyTextCount}
                    actTwoEnd={actTwoEnd}
                    actOneThreshold={actOneThreshold}
                    openReplyFieldID={openReplyFieldID}
                    setOpenReplyFieldID={setOpenReplyFieldID}
                    project_id={project_id}
                    iconWidth={"w-full md:w-[91%]"}
                    inpRightMargin={"mr-[47px] md:mr-[88px]"}
                    loading={loading}
                    replyText={replyText}
                    setReplyText={setReplyText}
                    addBeatTutorialPop={addBeatTutorialPop}
                    setAddBeatTutorialPop={setAddBeatTutorialPop}
                  />
                ) : commentsData?.counts > 0 &&
                  commentsData?.comments?.length === 0 ? (
                  <p className="text-center my-4">Comments Are Private.</p>
                ) : (
                  <p className="text-center my-4">No Comments Available</p>
                )}
              </div>

              {/* <div
                ref={lastCommentRef}
                // ref={commentsRef}
                className="flex-1 overflow-y-auto px-2 pt-3 pb-12"
              >
                {loading ? (
                  <div className="z-[1] lg:mt-[160px] xl:mt-[200px]">
                    <TypingLoader />
                  </div>
                ) : commentsData?.comments?.length > 0 ? (
                  <div>
                    {[...(commentsData?.comments || [])] // Create a shallow copy of the array to avoid modifying the original
                      .sort((a, b) => a.c_value - b.c_value) // Sort comments by c_value in ascending order
                      .map((comment, index) => (
                        <motion.div
                          key={comment.id + index}
                          initial={{ opacity: 0, y: 70 }} // Start from slightly below the final position
                          animate={{ opacity: 1, y: 0 }} // Move to the final position
                          exit={{ opacity: 0, y: -50 }} // Exit by moving above the screen
                          transition={{ duration: 0.5 }} // Adjust the duration as needed
                        >
                          <AllComments
                            handleOpenAllReplies={handleOpenAllReplies}
                            commentIdx={index + 1}
                            comments={comment}
                            data={data}
                            refetch={refetch}
                            openReplyField={openReplyField}
                            setOpenReplyField={setOpenReplyField}
                            replyToCommentID={replyToCommentID}
                            setReplyToCommentID={setReplyToCommentID}
                            replyResStat={replyResStat}
                            setCommentOwner={setCommentOwner}
                            setOpenAllReplies={setOpenAllReplies}
                            openAllReplies={openAllReplies}
                            commentRefetch={commentRefetch}
                            proImgUrl={proImgUrl}
                            setReplyField={setReplyField}
                            replyField={replyField}
                            // replyRef={replyRef}
                            handleReplyTextChange={handleReplyTextChange}
                            handlePostReplyToComment={handlePostReplyToComment}
                            replyLoading={replyLoading}
                            premiseData={premiseData}
                            replyTextCount={replyTextCount}
                            setReplyTextCount={setReplyTextCount}
                            // m_value={m_value}
                            actTwoEnd={actTwoEnd}
                            actOneThreshold={actOneThreshold}
                            openReplyFieldID={openReplyFieldID}
                            setOpenReplyFieldID={setOpenReplyFieldID}
                            project_id={project_id}
                            iconWidth={"w-full md:w-[91%]"}
                            inpRightMargin={"mr-[47px] md:mr-[88px]"}
                            loading={loading}
                            replyText={replyText}
                            setReplyText={setReplyText}
                            addBeatTutorialPop={addBeatTutorialPop}
                            setAddBeatTutorialPop={setAddBeatTutorialPop}
                          />
                        </motion.div>
                      ))}
                  </div>
                ) : commentsData?.counts > 0 &&
                  commentsData?.comments?.length === 0 ? (
                  <p className=" text-center my-4">Comments Are Private. </p>
                ) : (
                  <p className=" text-center my-4">No Comments Available </p>
                )}
              </div> */}

              {/* comment and reply div mobile */}
              <div className="fixed  w-[100%] bottom-1   inset-x-0 flex flex-col items-center">
                <div className="flex flex-col lg:hidden  w-full  border bg-white px-3 pb-4 shadow-md">
                  <div className="flex gap-1 items-center w-[50%] max-w-[180px]  mx-auto">
                    <AskIda
                      id={premiseId}
                      source_language={premiseData?.source_language}
                      {...{
                        user,
                        premiseOwner,
                        commentRefetch,
                        setOpenAllReplies,
                        setOpenReplyFieldID,
                        lastCommentRef,
                        isLoading,
                        setIsLoading,
                        setNoAccessPopup,
                        setService,
                      }}
                    />
                    <h3 className="text-[16px] font-[500]">or,</h3>
                  </div>
                  <PopupTextarea
                    {...{
                      premiseOwner,
                      user,
                      premiseId,
                      commentRefetch,
                      setOpenAllReplies,
                      setOpenReplyFieldID,
                      lastCommentRef,
                      commentField,
                      setCommentField,
                      setReplyField,
                      replyField,
                      replyRef,
                      setIsLoading,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {isDelete && (
            <DeletePremise
              setIsDelete={setIsDelete}
              refetch={refetch}
              isDelete={isDelete}
              deleteId={project_id}
              projectName={currentProjectName?.slice(0, 20)}
              popClose={popClose}
            />
          )}
          {openTransOtherPop && (
            <TransInOtherLang
              refetch={refetch}
              popClose={setOpenTransOtherPop}
              id={id}
              user={user}
              source_language={premiseData?.source_language}
              project_id={project_id}
            />
          )}
          {openCharacterChart && (
            <CharacterEditablePop
              setCharacterEditPop={setOpenCharacterChart}
              characterArray={characterArray}
              currentProjectData={currentProjectData}
              setCharacterArray={setCharacterArray}
              onlyAdd={onlyAdd}
              handleUpdateSavedChar={handleUpdateSavedChar}
              // handleSaveAsDraft={handleSaveAsDraft}
              characterLoading={isCharLoading}
              project_id={project_id}
              source_language={premiseData?.source_language}
              setOpenCharacterChart={setOpenCharacterChart}
            />
          )}
          {openViewTranslationsPop && (
            <ViewTranslationPop
              popClose={setOpenViewTranslationsPop}
              premiseId={viewTransactionPId}
            />
          )}
          {userMail === "Yes" && (
            <UserMail
              recipient={premiseOwner}
              data={{ user, id, userFirstName, userLastName }}
              setUserMail={setUserMail}
            />
          )}
          {userMail?.msg === "ShowBecomePrivilege" && (
            <NoAccessPopUp
              noAccessPopup={userMail}
              setNoAccessPopup={setUserMail}
            />
          )}
          {ownerMail && (
            <OwnerMail data={{ user, id }} setOwnerMail={setOwnerMail} />
          )}
          {/* {openPop && (
        <Popup
          popClose={() => setOpenPop(false)}
          {...{
            handleVisibility,
            handleMonetizing,
            setIsLiked,
            refetch,
            viewText,
          }}
          data={popupData}
          p={p}
        />
      )} */}
          {openCharacterChart && (
            <CharacterEditablePop
              setCharacterEditPop={setOpenCharacterChart}
              characterArray={characterArray}
              currentProjectData={currentProjectData}
              setCharacterArray={setCharacterArray}
              onlyAdd={onlyAdd}
              handleUpdateSavedChar={handleUpdateSavedChar}
              handleSaveAsDraft={handleSaveAsDraft}
              characterLoading={isCharLoading}
              project_id={premiseData?.project_id}
              source_language={premiseData?.source_language}
              setOpenCharacterChart={setOpenCharacterChart}
            />
          )}
          {openTransOtherPop && (
            <TransInOtherLang
              refetch={refetch}
              popClose={setOpenTransOtherPop}
              id={id}
              user={user}
              source_language={premiseData?.source_language}
              project_id={project_id}
            />
          )}
          {openAvailableForTranslationPop && (
            <AvailableForTranslationPop
              popClose={setOpenAvailableForTranslationPop}
              id={id}
              user={user}
              source_language={premiseData?.source_language}
              project_id={project_id}
              refetch={refetch}
            />
          )}
          {openViewTranslationsPop && (
            <ViewTranslationPop
              popClose={setOpenViewTranslationsPop}
              premiseId={viewTransactionPId}
              popCloseCmnt={() => setOpenPop(false)}
              {...{
                handleVisibility,
                handleMonetizing,
                // setIsLiked,
                refetch,
                viewText,
              }}
            />
          )}
          {openMonetizingPreferencesPop?.msg === "ShowBecomePrivilege" ? (
            <NoAccessPopUp
              noAccessPopup={openMonetizingPreferencesPop}
              setNoAccessPopup={setOpenMonetizingPreferencesPop}
            />
          ) : openMonetizingPreferencesPop?.msg === "LB" ||
            openMonetizingPreferencesPop?.msg ===
              "ShowBuyPackage_and_Allacarte" ? (
            <NoAccessLbPopUp
              noAccessLbPopUp={openMonetizingPreferencesPop}
              setNoAccessPopup={setOpenMonetizingPreferencesPop}
              service="PP_Monitizes"
            />
          ) : (
            openMonetizingPreferencesPop === "Yes" &&
            premiseData && (
              <MonetizePreferencePop
                popClose={setOpenMonetizingPreferencesPop}
                id={id}
                user={user}
              />
            )
          )}
          {noAccessLbPopUp?.msg === "ShowBecomePrivilege" ? (
            <NoAccessPopUp
              noAccessPopup={noAccessLbPopUp}
              setNoAccessPopup={setNoAccessLbPopUp}
            />
          ) : (
            (noAccessLbPopUp?.msg === "LB" ||
              noAccessLbPopUp?.msg === "ShowBuyPackage_and_Allacarte") && (
              <NoAccessLbPopUp
                noAccessLbPopup={noAccessLbPopUp}
                setNoAccessPopup={setNoAccessLbPopUp}
                service="PP_interactions"
              />
            )
          )}
          {translationRequestPop && (
            <ReqTranslationPop
              popClose={setTranslationRequestPop}
              id={id}
              user={user}
              source_language={premiseData?.source_language}
              project_id={project_id}
            />
          )}
          {saleRequestPop && (
            <ReqSalePop
              popClose={setSaleRequestPop}
              id={id}
              user={user}
              source_language={premiseData?.source_language}
              project_id={project_id}
            />
          )}
          {viewTrnRequests && (
            <BankDetailsPop
              // translationRequest={translationRequest}
              popClose={setViewTrnRequests}
              premiseId={viewTrnRequests}
            />
          )}
          {viewSaleRequests && (
            <SaleRequestedOwner
              popClose={setViewSaleRequests}
              setSaleIcon={setSaleRequestedOwner}
              premiseId={id}
            />
          )}
          {viewSale && (
            <PaySalePopup
              refetch={refetch}
              premiseId={saleId}
              popClose={setViewSale}
              sellingValue={premiseData?.sellingPrice}
              Userid={user}
            />
          )}
          {addPopup === "noUserName" && (
            <UserNamePopup {...{ refetch, setAddPopup }} />
          )}

          {noAccessPopup?.msg === "ShowBecomePrivilege" ? (
            <NoAccessPopUp
              noAccessPopup={noAccessPopup}
              setNoAccessPopup={setNoAccessPopup}
            />
          ) : (
            (noAccessPopup?.msg === "ShowBuyPackage_and_Allacarte" ||
              noAccessPopup?.msg === "LB") && (
              <NoAccessLbPopUp
                noAccessLbPopup={noAccessPopup}
                setNoAccessPopup={setNoAccessPopup}
                service={
                  service === "PP_AllowBrainstoming"
                    ? "PP_Brainstrom"
                    : "PP_interactions"
                }
              />
            )
          )}
          {notifyPopup && (
            <NotifyPopup
              popClose={setNotifyPopup}
              premiseId={premiseId}
              title={`This is currently unavailable for sale as there is a pending sale request from another User. Would you like us to notify you when this becomes available?`}
            />
          )}
          {afterFinalPostPremiseDemoPop && (
            <AfterFinalPostPremisePop
              popClose={() => setAfterFinalPostPremiseDemoPop(false)}
            />
          )}
          {addBeatTutorialPop && (
            <AddBeatTutorialPop popClose={() => setAddBeatTutorialPop(false)} />
          )}
          {openPopSource && (
            <Popup
              popClose={() => setOpenPopSource(false)}
              refetch={refetch}
              data={sourcePopData}
              {...{
                handleVisibility,
                handleMonetizing,
              }}
            />
          )}

          {sourcePremiseNotAvailabl && (
            <NoPremisePop
              popClose={() => setSourcePremiseNotAvailable(false)}
            />
          )}

          {likePopup && <LikePopup setLikePopup={setLikePopup} id={id} />}
        </div>
      </div>
    );
};
export default Popup;
