import { useEffect, useState } from "react";
import Select from "react-select";
import makeAnimated from "react-select/animated";
import { useGetFilteredLangQuery } from "../../../app/EndPoints/premisePoolApi";

const animatedComponents = makeAnimated();
const RefineFilters = ({
  showRefine,
  setShowRefine,
  setSortOrder,
  setRefetching,
  refetch,
  setText,
  setQueryUser,
  setLanguage,
  languageFilter,
  handleFilterSubmit,
  user,
  selectedLanguages,
  setSelectedLanguages,
}) => {
  // const user = useSelector((state) => state.user.id);

  const {
    data: lang,
    isLangLoading,
    refetch: langRefetch,
  } = useGetFilteredLangQuery();
  // console.log("languages", lang?.languages);

  const [searchText, setSearchText] = useState("");
  const [searchAuthor, setSearchAuthor] = useState(null);
  const [addByMe, setAddByMe] = useState(false);

  const [disabled, setDisabled] = useState(false);

  const [checkDisable, setCheckDisabled] = useState(false);
  // const [selectedLanguages, setSelectedLanguages] = useState();

  // console.log(selectedLanguages);

  const handleLangFilterClear = () => {
    setLanguage("");
    setSelectedLanguages(null);
    refetch();
    setRefetching(true);
    setShowRefine(false);
  };

  const handleMe = (e) => {
    setAddByMe(e.target.checked);
    if (e.target.value) {
      setSearchAuthor(user);
      setAddByMe(!addByMe);
    } else {
      setAddByMe(false);
    }
  };

  useEffect(() => {
    if (searchText.length > 0 || addByMe || selectedLanguages) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  }, [addByMe, searchText, selectedLanguages]);

  // const handleFilterSubmit = () => {
  //   applyFilter(searchText, searchAuthor, selectedLanguages?.value);
  //   addByMe && searchText?.length === 0 && setCheckDisabled(true);
  // };

  const applyFilter = (text, author, language) => {
    // console.log();
    setText(text);
    setQueryUser(author);
    setLanguage(language);
    refetch();
    setRefetching(true);
  };

  const mappedLanguages = lang?.languages?.map((languageObj) => {
    const key = Object.keys(languageObj)[0];
    const value = languageObj[key];

    return {
      value: key,
      label: value,
    };
  });

  const handleLanguageChange = (selectedOptions) => {
    setSelectedLanguages(selectedOptions);
  };

  const customStyles = {
    option: (provided, state) => ({
      ...provided,
      fontSize: "14px", // Adjust the font size as needed
      padding: "2px 8px", // Adjust the padding to increase the gap between options
      backgroundColor: state.isFocused ? "#00c3ff" : "#fafafa", // Change the background color on hover
      color: state.isFocused ? "#fff" : "#000000", // Change text color on hover
    }),
    menu: (provided) => ({
      ...provided,
      marginTop: "0px", // Adjust the gap between the label and the dropdown
    }),
  };
  return (
    <div
      className={` left-0 ${
        showRefine ? "visible" : "invisible"
      } bg-[#FAFAFA] px-[16px] py-[12px] rounded-[8px] w-[324px]  absolute left-0 lg:left-[-142px] md:w-[405px] mx:left-[-18px] top-[50px] z-10 border border-[#eaeaea] shadow-lg shadow-[#9a9a9a] `}
    >
      <div>
        {/* <p className="font-semibold mb-2">Search parameters</p> */}
        <div className="w-full r mx-3">
          {/* <div className="w-[95%]">
            <label className="text-[14px] text-[#252525] font-[400] mb-2 ">
              Choose A Language
            </label>
            <Select
              className={`${showRefine ? "visible" : "hidden"} text-[14px]`}
              theme={(theme) => ({
                ...theme,
                borderRadius: 8,
                height: 32,

                colors: {
                  ...theme.colors,
                  primary25: "#EAEAEA",
                  primary: "#EAEAEA",
                },
              })}
              styles={customStyles}
              closeMenuOnSelect={true}
              components={animatedComponents}
              options={mappedLanguages}
              onChange={handleLanguageChange}
              value={selectedLanguages}
            />
          </div> */}

          <div className="w-[95%]">
            <label className="text-[14px] text-[#252525] font-[400] mb-2 block">
              Choose A Language
            </label>

            {/* ✅ React Select for Desktop */}
            <div className={`${showRefine ? "visible" : "hidden"}  lgVisible`}>
              <Select
                className="text-[14px]"
                theme={(theme) => ({
                  ...theme,
                  borderRadius: 8,
                  colors: {
                    ...theme.colors,
                    primary25: "#EAEAEA",
                    primary: "#EAEAEA",
                  },
                })}
                styles={customStyles}
                closeMenuOnSelect
                components={animatedComponents}
                options={mappedLanguages}
                onChange={handleLanguageChange}
                value={selectedLanguages}
              />
            </div>

            {/* ✅ Native Select for Mobile */}
            <div className={`${showRefine ? "visible" : "hidden"}  lgHidden `}>
              <select
                className="w-full border border-gray-300 rounded-lg p-2 text-[14px] text-[#252525] focus:outline-none focus:ring-2 bg-[#fafafa] focus:ring-[#EAEAEA]"
                onChange={(e) => {
                  const selected = mappedLanguages.find(
                    (lang) => lang.value === e.target.value
                  );
                  handleLanguageChange(selected);
                }}
                value={selectedLanguages?.value || ""}
              >
                <option value="" disabled>
                  Select...
                </option>
                {mappedLanguages?.map((lang) => (
                  <option key={lang.value} value={lang.value}>
                    {lang.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="flex flex-row-reverse gap-4 mt-[8px]">
          <button
            disabled={disabled}
            className={` px-4 py-[4px] text-[14px] font-[400] text-white rounded-[8px] ${
              disabled ? "bg-[#ACDDE7]" : "bg-[#00c3ff]"
            }`}
            onClick={() => {
              handleFilterSubmit();
              languageFilter(selectedLanguages?.value);
              setShowRefine(false);
            }}
          >
            Apply filter
          </button>
          <button
            disabled={disabled}
            className={`clear-m px-4 py-[2px] text-[14px] font-[400] rounded-[8px] ${
              disabled
                ? "bg-[#ACDDE7] text-white"
                : "bg-[#FAFAFA] text-[#00c3ff] border !border-[#00c3ff] "
            }`}
            onClick={handleLangFilterClear}
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};

export default RefineFilters;
